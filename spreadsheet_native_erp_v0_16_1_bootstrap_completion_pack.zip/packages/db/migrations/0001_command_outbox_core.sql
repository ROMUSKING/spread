-- Phase 0 stub migration. Canonical DDL remains in docs/data/command-outbox-retention-partitioning.md.
-- AGENT-010/020 must replace this file with real migrations generated from the canonical data contract.
SELECT 1;
