# packages/ui

**Version:** 0.16.1  
**Status:** Phase 0 stub package.

This package is part of the TypeScript-first Phase 0 monorepo skeleton. Implement only the work order assigned to the PR. Do not introduce post-MVP runtimes into the Phase 0 edit path.

Canonical guidance:

```text
docs/snapshot-v0.16.1.md
AGENTS.md
docs/implementation/phase0-agent-work-orders.md
```
