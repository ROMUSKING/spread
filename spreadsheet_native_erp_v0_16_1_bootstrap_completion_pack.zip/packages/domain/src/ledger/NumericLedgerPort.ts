export type NumericTransferDraft = {
  transferIdDec: string;
  debitAccountIdDec: string;
  creditAccountIdDec: string;
  amountDec: string;
  ledgerCode: string;
  movementKind: string;
  payloadHash: string;
};

export type NumericLedgerResult =
  | { status: "created"; transferIdDec: string }
  | { status: "exists_same_payload"; transferIdDec: string }
  | { status: "exists_different_payload"; transferIdDec: string; code: "TRANSFER_PAYLOAD_HASH_CONFLICT" }
  | { status: "rejected"; code: string; message: string };

export interface NumericLedgerPort {
  createTransfer(draft: NumericTransferDraft): Promise<NumericLedgerResult>;
}

export class PostgresMvpNumericLedgerAdapter implements NumericLedgerPort {
  constructor(private readonly tx: { query: (sql: string, params?: readonly unknown[]) => Promise<unknown> }) {}

  async createTransfer(draft: NumericTransferDraft): Promise<NumericLedgerResult> {
    if (draft.debitAccountIdDec === draft.creditAccountIdDec) {
      return { status: "rejected", code: "SELF_TRANSFER_REJECTED", message: "Debit and credit accounts must differ." };
    }

    // Stub: AGENT-012 must replace with numeric_transfers insert inside the caller's PostgreSQL transaction.
    await this.tx.query("/* insert numeric transfer draft */", [draft.transferIdDec, draft.payloadHash]);
    return { status: "created", transferIdDec: draft.transferIdDec };
  }
}

export class TigerBeetleShadowAdapter implements NumericLedgerPort {
  async createTransfer(_draft: NumericTransferDraft): Promise<NumericLedgerResult> {
    throw new Error("TigerBeetle runtime is post-MVP and must not be used in Phase 0 edit path.");
  }
}
