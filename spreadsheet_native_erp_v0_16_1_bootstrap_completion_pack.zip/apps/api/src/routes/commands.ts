import type { SubmitCommandRequest, SubmitCommandResponse } from "@erp/contracts/command-api";

export async function submitCommandStub(request: SubmitCommandRequest): Promise<SubmitCommandResponse> {
  // Stub: AGENT-011/012 will wire command claim, idempotency, transaction boundary, and status persistence.
  return { commandId: request.commandId, status: "received" };
}
